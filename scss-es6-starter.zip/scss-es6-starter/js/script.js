$(document).ready(function(){

  // js code

});